require 'sinatra/base'
require 'openssl'
require 'webrick'
require 'webrick/https'

class App1 < Sinatra::Base
  get '/hello_ssl' do
    'Hello SSL '
  end
end

app = Rack::Builder.new do 
   run App1
end

webrick_options = {
  :Port               => 8443,
  :Host => "0.0.0.0",
  :Logger             => WEBrick::Log::new($stdout, WEBrick::Log::DEBUG),
  :DocumentRoot       => "./public",
  :SSLEnable          => true,
  :SSLCertificate     => OpenSSL::X509::Certificate.new(  File.open("./asynchronous_server.crt").read),
  :SSLCACertificateFile     => "./ca.crt",
  :SSLPrivateKey      => OpenSSL::PKey::RSA.new(          File.open("./asynchronous_server.key").read),
  :SSLCertName        => [ [ "CN",WEBrick::Utils::getservername ] ]
}

Rack::Handler::WEBrick.run app, webrick_options
